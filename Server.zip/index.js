const express = require('express');
var mysql = require('mysql');

const app = express();
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});






var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'sarahaDB'
});
 
let user_id;
// get user profile
app.get('/profile/:id', (req, res) => {
   try{
    let id = req.params.id;
    connection.query('SELECT * FROM users WHERE user_id='+ id , function (error, results, fields) {
      if (error) throw error;
      res.json(results); 
    }); 
   //connection.end();
   }
   catch(e){
      res.json("we having a problem ");
   }


});


//get posts user posts
app.get('/posts',(req, res) => {
  jwt.verify(req.query.token, req.query.secret, function(err, decoded) {
   
    
    try{
      connection.query('SELECT * FROM posts WHERE user_id='+ decoded.user_id , function (error, results, fields) {
        if (error) throw res.json("we are getting problems ");
       res.json(results);
         
      }); 
     // connection.end();
    }catch(e){
  
    }






   
    if(err){
      res.status(404).json("we dont have that !");
    }
  });







  
  

});

//sign up
app.post('/signup', (req, res) => {
  let add = "INSERT INTO `users` (`user_id`, `username`, `full_name`, `email_adress`, `password`, `bio`, `creation_date`)  VALUES (NULL, '"+req.body.username+ "','"+req.body.full_name+ "', '"+req.body.email_adress+ "', '"+req.body.password+ "', '"+req.body.bio+ "', current_timestamp())";
try{
  connection.query(add , function (error, results, fields) {
     if(error){
      res.json("we having some problems adding you check your entries");
     }else{
      res.json("you have been added successfully"); 
     }

   }); 
   // connection.end();

}
catch(error){
  res.json("we having some problems adding you try again later");
}

});

//log in
app.post('/login', (req, res) => {
  //connection.connect();
  
  let add = "SELECT * FROM users WHERE ( email_adress = '"+req.body.email_adress+"' AND password = '"+req.body.password+"')";
  try{
    connection.query(add , function (error, results, fields) {
      if (error) throw res.json("we having some problems try again later");
      
      if(results[0] != null){
        let pyload = { 
          user_id : results[0].user_id,
          username : results[0].username,
          full_name : results[0].username,
          email_adress : results[0].email_adress,
          
         }
        var token = jwt.sign(pyload, 'mysecret');
       
        res.setHeader('Set-Cookie', token);
        res.json({
          token,
          message : "you are sign in successfully"
        }); 
        // save to cookies
         //redirect
        
        //res.send('ok');
        //connection.end();
      }else{
        res.json("email or password is wrong");
      }
     
     }); 
     
  }
  catch(e){
     res.json("email or password is wrong ");
  }
  

});

// find user and getting the id 
app.get('/:username',(req, res) => {
let user_url =  req.params.username;
//console.log(user);
//res.redirect('http://google.com'+user);
let add = "SELECT user_id FROM users WHERE (username = '"+user_url+"')";
try{
  connection.query(add , function (error, results, fields) {
     if(error){
      res.json("we cant find this user");
     }else{
       user_id = results[0].user_id;
      
      res.json({user_id :user_id});
     }
   }); 
   // connection.end();
}
catch(error){res.json("we having some problems adding you try again later");}
})

//add a post
app.post('/addpost', (req, res) => {
  let add = "INSERT INTO `posts` (`post_id`, `user_id`, `content`, `creation_date`)  VALUES (NULL, '"+user_id+ "','"+req.body.content+ "', current_timestamp())";
try{
  connection.query(add , function (error, results, fields) {
     if(error){
      res.json("we having some problems adding you check your entries");
     }else{
      res.json("post have been added successfully"); 
     }

   }); 
   // connection.end();

}
catch(error){
  res.json("we having some problems adding you try again later");
}

});
app.get('/test', (req, res) => {
  console.log("good");
 
});
//listning
app.listen(8000, () => {
  console.log('listening ')
});
